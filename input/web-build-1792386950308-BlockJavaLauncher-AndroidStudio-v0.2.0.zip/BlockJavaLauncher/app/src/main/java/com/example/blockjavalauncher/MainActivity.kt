package com.example.blockjavalauncher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101418)
private val Panel = Color(0xFF1B2329)
private val Green = Color(0xFF35C86B)
private val TextMain = Color(0xFFF4F7F8)
private val TextMuted = Color(0xFFACB8BF)
private val versions = listOf("1.21.8", "1.21.4", "1.20.6", "1.20.4", "1.20.1", "1.19.4", "1.18.2", "1.16.5")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LauncherScreen() }
    }
}

@Composable
private fun LauncherScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("launcher", 0) }
    var selectedTab by remember { mutableStateOf("Играть") }
    var version by remember { mutableStateOf(prefs.getString("version", "1.20.4") ?: "1.20.4") }
    var ram by remember { mutableFloatStateOf(prefs.getFloat("ram", 2f)) }
    var modsUri by remember { mutableStateOf(prefs.getString("mods_uri", null)?.let(Uri::parse)) }
    var mods by remember { mutableStateOf(emptyList<String>()) }
    var showVersions by remember { mutableStateOf(false) }

    fun reloadMods() {
        val uri = modsUri ?: return
        mods = runCatching { DocumentFile.fromTreeUri(context, uri)?.listFiles()?.filter { it.isFile }?.map { it.name ?: "Без имени" } ?: emptyList() }.getOrDefault(emptyList())
    }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            modsUri = uri
            prefs.edit().putString("mods_uri", uri.toString()).apply()
            reloadMods()
            Toast.makeText(context, "Папка модов подключена", Toast.LENGTH_SHORT).show()
        }
    }
    val modPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val target = modsUri?.let { DocumentFile.fromTreeUri(context, it) }
            if (target == null || !target.canWrite()) {
                Toast.makeText(context, "Сначала выбери папку mods", Toast.LENGTH_LONG).show()
            } else {
                val name = runCatching { context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } }.getOrNull() ?: "mod.jar"
                if (!name.endsWith(".jar", true)) {
                    Toast.makeText(context, "Выбери файл мода .jar", Toast.LENGTH_LONG).show()
                } else {
                    val copied = runCatching {
                        target.findFile(name)?.delete()
                        val outFile = target.createFile("application/java-archive", name) ?: error("Не удалось создать файл")
                        context.contentResolver.openInputStream(uri).use { input ->
                            requireNotNull(input) { "Не удалось прочитать файл" }
                            context.contentResolver.openOutputStream(outFile.uri, "w").use { output ->
                                requireNotNull(output) { "Нет доступа к папке" }
                                input.copyTo(output)
                            }
                        }
                        true
                    }.getOrDefault(false)
                    Toast.makeText(context, if (copied) "Мод скопирован: $name" else "Не удалось скопировать мод", Toast.LENGTH_LONG).show()
                    reloadMods()
                }
            }
        }
    }

    LaunchedEffect(modsUri) { reloadMods() }

    MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Panel, onPrimary = Color.Black, onBackground = TextMain, onSurface = TextMain)) {
        Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).background(Color(0xFF2B583B), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("▦", fontSize = 30.sp, color = Green, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Block Java Launcher", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextMain)
                    Text("Minecraft Java Edition · Android 14+", color = TextMuted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("Играть", "Версии", "Моды", "Настройки").forEach { tab ->
                    TextButton(onClick = { selectedTab = tab }, modifier = Modifier.weight(1f)) { Text(tab, color = if (selectedTab == tab) Green else TextMuted, fontWeight = FontWeight.SemiBold, fontSize = 12.sp) }
                }
            }
            Spacer(Modifier.height(18.dp))
            when (selectedTab) {
                "Играть" -> {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(18.dp)) {
                        Text("ТВОЙ МИР ЖДЁТ", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Minecraft Java", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = TextMain)
                        Text("Запуск через совместимую Java-среду", color = TextMuted, fontSize = 14.sp)
                        Spacer(Modifier.height(18.dp))
                        Text("Версия: $version", color = TextMuted, fontSize = 13.sp)
                        OutlinedButton(onClick = { selectedTab = "Версии" }, modifier = Modifier.fillMaxWidth()) { Text("Выбрать версию", color = TextMain) }
                        Spacer(Modifier.height(8.dp))
                        Text("Память: ${ram.toInt()} ГБ", color = TextMuted, fontSize = 13.sp)
                        Slider(value = ram, onValueChange = { ram = it }, onValueChangeFinished = { prefs.edit().putFloat("ram", ram).apply() }, valueRange = 1f..6f, steps = 4)
                        Button(onClick = {
                            val intent = context.packageManager.getLaunchIntentForPackage("net.kdt.pojavlaunch")
                            if (intent != null) context.startActivity(intent)
                            else Toast.makeText(context, "PojavLauncher не найден. Установи совместимый лаунчер из его официального проекта.", Toast.LENGTH_LONG).show()
                        }, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Green), shape = RoundedCornerShape(12.dp)) { Text("ЗАПУСТИТЬ JAVA-ЛАУНЧЕР", color = Color(0xFF07140B), fontWeight = FontWeight.ExtraBold) }
                        Spacer(Modifier.height(10.dp))
                        Text("Важно: выбранная версия и память пока не передаются автоматически в PojavLauncher. Настрой их также внутри него.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    InfoCard("Установка модов", "Открой вкладку «Моды» и выбери настоящую папку mods игры через системный выбор папок Android. Затем импортируй .jar-файлы.")
                    Spacer(Modifier.height(12.dp))
                    InfoCard("Совместимость", "Для модов нужна подходящая версия Minecraft и загрузчик Fabric или Forge. Мод должен соответствовать версии игры и загрузчика.")
                }
                "Версии" -> {
                    Text("Версии Minecraft", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Это список для выбора в интерфейсе, а не каталог загрузок. Установи выбранную версию в Java-лаунчере.", color = TextMuted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    versions.forEach { v ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Minecraft $v", color = TextMain, fontWeight = FontWeight.SemiBold); Text(if (v == version) "Выбрана" else "Java Edition", color = TextMuted, fontSize = 12.sp) }
                            Button(onClick = { version = v; prefs.edit().putString("version", v).apply(); selectedTab = "Играть" }, colors = ButtonDefaults.buttonColors(containerColor = if (v == version) Color(0xFF263C2E) else Green)) { Text(if (v == version) "Выбрана" else "Выбрать", color = if (v == version) Green else Color.Black) }
                        }
                    }
                }
                "Моды" -> {
                    Text("Менеджер модов", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Подключи папку mods установленной игры. На Android 14 доступ к папкам выдаётся вручную.", color = TextMuted, fontSize = 13.sp, lineHeight = 18.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { folderPicker.launch(modsUri) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(if (modsUri == null) "Выбрать папку mods" else "Изменить папку mods", color = Color.Black) }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { modPicker.launch(arrayOf("application/java-archive", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) { Text("Импортировать мод .jar", color = TextMain) }
                    Spacer(Modifier.height(12.dp))
                    InfoCard("Файлы в папке (${mods.size})", if (modsUri == null) "Папка ещё не выбрана." else if (mods.isEmpty()) "Папка подключена, но файлы не найдены." else mods.joinToString("\n") { "• $it" })
                    Spacer(Modifier.height(12.dp))
                    Text("Импорт копирует .jar в выбранную папку. Это не устанавливает Forge/Fabric и не гарантирует совместимость мода. Не импортируй файлы из недоверенных источников.", color = TextMuted, fontSize = 12.sp, lineHeight = 17.sp)
                }
                else -> {
                    Text("Настройки", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    InfoCard("Объём памяти", "Сейчас в интерфейсе выбрано ${ram.toInt()} ГБ. Это значение сохраняется в приложении, но пока не применяется к Java-процессу PojavLauncher.")
                    Spacer(Modifier.height(12.dp))
                    InfoCard("Среда запуска", "Для запуска используется установленный пакет net.kdt.pojavlaunch. Версии и моды настраиваются внутри самой среды; прямой интеграции с её внутренними настройками пока нет.")
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/PojavLauncherTeam/PojavLauncher"))) }, modifier = Modifier.fillMaxWidth()) { Text("Официальный проект PojavLauncher", color = Green) }
                    Spacer(Modifier.height(8.dp))
                    Text("Block Java Launcher · 0.2.0 · неофициальный проект", color = TextMuted, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
    if (showVersions) AlertDialog(onDismissRequest = { showVersions = false }, title = { Text("Версия") }, confirmButton = { TextButton(onClick = { showVersions = false }) { Text("Закрыть") } })
}

@Composable
private fun InfoCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(16.dp)) {
        Text(title, color = TextMain, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(7.dp))
        Text(body, color = TextMuted, fontSize = 13.sp, lineHeight = 19.sp)
    }
}
